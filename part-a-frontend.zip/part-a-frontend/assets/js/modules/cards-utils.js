export class codeMenuCard {
    constructor(langName, desc, difficultyId, categoryId) {
        this.langName = langName;
        this.description = desc;
        this.difficultyLookupId = difficultyId;
        this.categoryLookupId = categoryId;
    }
}